package com.ricardoguzman.puppy.presentador;

/**
 * Created by ricgu on 23/12/2016.
 */

public interface IRecyclerViewFragmentPresenter {
    public void obtenerMascotasBD();
    public void mostrarMascotasRV();
}
